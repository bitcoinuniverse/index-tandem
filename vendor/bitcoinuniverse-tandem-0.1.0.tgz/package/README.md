# Tandem

Tandem is a Bitcoin protocol for one jointly controlled, evolving object per valid CREATE transaction. Each active object is carried by an exact 20,000-sat native SegWit 2-of-2 P2WSH output. The current pair can add a chapter, rotate one or both keys, close cooperatively, or recover through a pre-signed relative-locktime refund.

This repository is the canonical home for the normative protocol artifact, reference parser, validator, state reducer, SDK, CLI, schemas, and signed-vector tooling.

## Status

The normative specification is finalized. Mainnet activation remains closed.

The normative SHA256 is `caa77ce0122c0b833fc5f099191b54280b0481be325bdc98f2b48b0b905b923f`. Maintainer signatures and a final evidence manifest are still required before any public network INIT. Regtest, public signet, independent-indexer agreement, recovery, signer, security, accessibility, legal, and production-rehearsal gates must all pass before a mainnet launch decision.

## Consensus boundary

- The raw bytes of the normative specification define Tandem.
- A network deployment selects one configured INIT transaction.
- Any normative byte change requires a new specification hash, INIT, namespace, and protocol ID.
- Off-chain manifests affect presentation only. Their availability never changes protocol validity.
- Wallet recovery attestations and service sessions are not consensus state.

## Safety boundary

Known protocol UTXOs and unknown UTXOs are protected from ordinary coin selection. State-changing construction and broadcast fail closed whenever the two independent indexers do not agree at the same canonical height.

## Repository map

- normative specification: canonical protocol bytes at the repository root
- `docs/implementation-baseline.md`: frozen implementation decisions
- `docs/deviations.md`: decisions made while converting the approved design into code
- `docs/launch-gates.md`: evidence ledger and activation policy
- `schemas/`: non-consensus JSON schemas
- `src/`: reference parser, validator, reducer, SDK, and CLI
- `vectors/`: generated valid, invalid, root, reorg, PSBT, and recovery fixtures

## License

MIT. See `LICENSE`.
