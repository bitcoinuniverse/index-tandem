# Tandem v1

Tandem v1 is a Bitcoin protocol for one jointly controlled, evolving object per valid CREATE transaction. Each active object is carried by an exact 20,000-sat native SegWit 2-of-2 P2WSH output. The current pair can add a chapter, rotate one or both keys, close cooperatively, or recover through a pre-signed relative-locktime refund.

This repository is the canonical home for the normative protocol artifact, reference parser, validator, state reducer, SDK, CLI, schemas, and signed-vector tooling.

## Status

Normative candidate frozen. Mainnet activation is closed.

The candidate SHA256 is `912e8ebad7eeb40c86734724962e4c8b9ba27d248600ff93fcb2b5bf9efc2167`. Maintainer signatures and a final evidence manifest are still required before any public network INIT. Regtest, public signet, independent-indexer agreement, recovery, signer, security, accessibility, legal, and production-rehearsal gates must all pass before a mainnet launch decision.

## Consensus boundary

- The raw bytes of `tandem-v1.md` define Tandem v1.
- A network deployment selects one configured INIT transaction.
- Any normative byte change requires a new specification hash, INIT, namespace, and protocol ID.
- Off-chain manifests affect presentation only. Their availability never changes protocol validity.
- Wallet recovery attestations and service sessions are not consensus state.

## Safety boundary

Known protocol UTXOs and unknown UTXOs are protected from ordinary coin selection. State-changing construction and broadcast fail closed whenever the two independent indexers do not agree at the same canonical height.

## Repository map

- `tandem-v1.md`: normative protocol bytes
- `docs/implementation-baseline.md`: frozen implementation decisions
- `docs/deviations.md`: decisions made while converting the approved design into code
- `docs/launch-gates.md`: evidence ledger and activation policy
- `schemas/`: non-consensus JSON schemas
- `src/`: reference parser, validator, reducer, SDK, and CLI
- `vectors/`: generated valid, invalid, root, reorg, PSBT, and recovery fixtures

## License

MIT. See `LICENSE`.
